//?How many Paths?
addEventListener('load', function() {
        //On load the animation will start on .port_photos class
        var elements = document.querySelectorAll('.port_photos');
        for (var i = 0; i < elements.length; i++) {
          elements[i].style.opacity = 1;
        }
      });
